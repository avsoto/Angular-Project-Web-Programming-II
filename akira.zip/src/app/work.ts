export class Work{
    id_post : number;
    titulo : string;
    tema : string;
    cuerpo : string;
    id_usuario : number;
}