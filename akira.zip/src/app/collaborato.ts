export class Collaborator{
    id_usuario : number;
    nombre : string;
    apellido : string;
    cargo :  string;
    pais : string;
    correo : string; 
}