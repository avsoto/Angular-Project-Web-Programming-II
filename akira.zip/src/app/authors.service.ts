import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Author } from './author';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthorService {
  authors : Author[];

  constructor(private http: HttpClient) { }

  authorSelect(): Observable<Author[]>{
    const rutaAuthor = "http://localhost:84/libreriaservicio/autores.php";
    return this.http.post<Author[]>(rutaAuthor, null).pipe(map((res) => {
      //La variable res contiene los datos del servicio web 
      this.authors = JSON.parse(JSON.stringify(res));

      return this.authors;
    })
    );
  }
  
  authorInsert(nombre,apellido,cargo,pais,descripcion,correo){
    const rutaAuthor = "http://localhost:84/libreriaservicio/autor-insertar.php";

    const formData: FormData = new FormData();
    formData.append("nombre", nombre);
    formData.append("apellido", apellido );
    formData.append("cargo",cargo );
    formData.append("pais", pais );
    formData.append("descripcion", descripcion );
    formData.append("correo",correo);

    return this.http.post(rutaAuthor, formData).pipe(map((res) => {
      return res;
    }))
  }

  authorUpdate(id_usuario,nombre,apellido,cargo,pais,descripcion,correo){
    const rutaAuthor = "http://localhost:84/libreriaservicio/autor-actualizar.php";

    const formData: FormData = new FormData();
    formData.append("id_usuario", id_usuario);
    formData.append("nombre", nombre);
    formData.append("apellido", apellido );
    formData.append("cargo",cargo );
    formData.append("pais", pais );
    formData.append("descripcion", descripcion );
    formData.append("correo",correo);

    return this.http.post(rutaAuthor, formData);
  }

  authorDelete(id_usuario){
    const rutaAuthor = "http://localhost:84/libreriaservicio/autor-eliminar.php";

    const formData: FormData = new FormData();
    formData.append("id_usuario", id_usuario);

    return this.http.post(rutaAuthor, formData);
  }
}

