export class Author{
    id_usuario : number;
    nombre : string;
    apellido : string;
    cargo :  string; 
    pais: string;
    descripcion: string; 
    correo: string; 
}